# Form Data for Django Forms APP
form_choices = ((1, 'Food'),(2, 'Drinks'),(3, 'Movies'),(4, 'Rest'),(5, 'Sports'))
year_data = [x for x in range(1980,2031)]
