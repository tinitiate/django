from django.apps import AppConfig


class AppDbQuerysetsConfig(AppConfig):
    name = 'app_db_querysets'
