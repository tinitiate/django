from django.apps import AppConfig


class AppDbSerializerConfig(AppConfig):
    name = 'app_db_serializer'
