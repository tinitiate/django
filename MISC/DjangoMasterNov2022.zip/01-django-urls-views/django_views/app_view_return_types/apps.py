from django.apps import AppConfig


class AppViewReturnTypesConfig(AppConfig):
    name = 'app_view_return_types'
