from django.apps import AppConfig


class AppMultipleViewsConfig(AppConfig):
    name = 'app_multiple_views'
