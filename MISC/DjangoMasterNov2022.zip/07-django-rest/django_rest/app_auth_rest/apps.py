from django.apps import AppConfig


class AppAuthRestConfig(AppConfig):
    name = 'app_auth_rest'
