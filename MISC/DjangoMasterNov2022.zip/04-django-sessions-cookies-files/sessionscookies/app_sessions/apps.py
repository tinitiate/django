from django.apps import AppConfig


class AppSessionsConfig(AppConfig):
    name = 'app_sessions'
