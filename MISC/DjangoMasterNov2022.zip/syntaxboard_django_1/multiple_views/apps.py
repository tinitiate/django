from django.apps import AppConfig


class MultipleViewsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'multiple_views'
